<?php

declare(strict_types=1);

/*
 * Copy this file to config/backtester.php and fill in the operator values.
 * Keep the real file outside version control. Environment variables override
 * the most sensitive values and are preferred when the host supports them.
 */
return [
    'app' => [
        'environment' => getenv('BACKTESTER_ENV') ?: 'production',
        'timezone' => 'Europe/Berlin',
        'public_base_url' => getenv('BACKTESTER_PUBLIC_BASE_URL') ?: 'https://smstark-projekt.de/dashboards/backtester',
        'max_assets_per_request' => 9,
        'max_range_days' => 14610,
        'min_amount' => 100.0,
        'max_amount' => 10000000.0,
    ],
    'database' => [
        'host' => getenv('BACKTESTER_DB_HOST') ?: '[bitte hier einsetzen]',
        'port' => (int) (getenv('BACKTESTER_DB_PORT') ?: 3306),
        'name' => getenv('BACKTESTER_DB_NAME') ?: '[bitte hier einsetzen]',
        'username' => getenv('BACKTESTER_DB_USER') ?: '[bitte hier einsetzen]',
        'password' => getenv('BACKTESTER_DB_PASSWORD') ?: '[bitte hier einsetzen]',
        'charset' => 'utf8mb4',
    ],
    'providers' => [
        'fred' => [
            'base_url' => 'https://api.stlouisfed.org/fred/series/observations',
            'api_key' => getenv('BACKTESTER_FRED_API_KEY') ?: '[bitte hier einsetzen]',
            'timeout_seconds' => 20,
            'max_retries' => 3,
            'retry_base_ms' => 500,
            'backfill_chunk_days' => 7300,
            'live_updates_from' => '2026-08-03',
        ],
        'alpha_vantage' => [
            'base_url' => 'https://www.alphavantage.co/query',
            'api_key' => getenv('BACKTESTER_ALPHA_VANTAGE_API_KEY') ?: '[bitte hier einsetzen]',
            'timeout_seconds' => 20,
            'max_retries' => 3,
            'retry_base_ms' => 500,
            'backfill_chunk_days' => 7300,
            'live_updates_from' => '2026-08-03',
        ],
        'coingecko' => [
            'base_url' => getenv('BACKTESTER_COINGECKO_BASE_URL') ?: 'https://api.coingecko.com/api/v3',
            'api_key' => getenv('BACKTESTER_COINGECKO_API_KEY') ?: '[bitte hier einsetzen]',
            'api_key_header' => getenv('BACKTESTER_COINGECKO_KEY_HEADER') ?: 'x-cg-demo-api-key',
            'timeout_seconds' => 20,
            'max_retries' => 3,
            'retry_base_ms' => 500,
            'backfill_chunk_days' => 365,
        ],
        'csv' => [
            'directory' => dirname(__DIR__) . '/var/import',
            'backfill_chunk_days' => 7300,
        ],
    ],
    'sync' => [
        'overlap_days' => 10,
        'lock_seconds' => 180,
        'page_visit_max_assets' => 3,
        'page_visit_rate_limit' => 12,
        'page_visit_rate_window_minutes' => 15,
        'success_check_delay_hours' => 18,
        'failure_backoff_max_hours' => 48,
        'log_file' => dirname(__DIR__) . '/logs/backtester.log',
    ],
    'security' => [
        'cron_secret' => getenv('BACKTESTER_CRON_SECRET') ?: '[bitte hier einsetzen]',
        'allowed_origin' => getenv('BACKTESTER_ALLOWED_ORIGIN') ?: 'https://smstark-projekt.de',
    ],
    'features' => [
        'inflation' => false,
        'transaction_costs' => false,
        'taxes' => false,
        'recurring_investments' => false,
        'real_estate' => false,
        'magnificent_seven' => false,
    ],
];
